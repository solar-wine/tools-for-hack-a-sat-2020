# encoding: ascii-8bit

USER_VERSION = "OpenSatKit 2.1"